function trocaImg(a) {    
	document.getElementById("img").src=a;
}